#include<iostream>
#include<iomanip>

using namespace std;

int main()
{
	//Declare the variables for input
	float initInv;
	float monDep;
	float AnuInt;
	float months;
	float years;
	//Declare variable to store year end total amount, interest and year end interest
	float totalAmount;
	float intAmt; 
	float yearTotInt;

	//Display 
	cout << "********************************\n";
	cout << "********** Data Input************\n";
	cout << "Initial Investment Amount: \n";
	cout << "Monthly Deposit: \n";
	cout << "Annual Interest: \n";
	cout << "Number of years: \n";

	//Wait for the input from the user
	system("PAUSE");

	//Data from user
	cout << "********************************\n";
	cout << "********** Data Input************\n";
	cout << "Initial Investment Amount: $";
	cin >> initInv;
	cout << "Monthly Deposit: $";
	cin >> monDep;
	cout << "Annual Interest: %";
	cin >> AnuInt;
	cout << "Number of years:";
	cin >> years;
	months = years * 12;

	//Wait for the input from the user
	system("PAUSE");

	//Set total amount to inital investment to be updated
	totalAmount = initInv;

	//Display the year-end data without Additional Monthly Deposits
	cout << "Balance and Interest Without Additional Monthly Deposits\n";
	cout << "==============================================================\n";
	cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";
	cout << "------------------------------------------------------------\n";


	for (int i = 0; i < years; i++) {

		//Calculate the yearly interest
		intAmt = (totalAmount) * ((AnuInt / 100));

		//Calculate the year end total
		totalAmount = totalAmount + intAmt;

		//Print results to the table showcasing only two decimal points
		cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalAmount << "\t\t\t$" << intAmt << "\n";
	}

	//Set total amount to initial investment to be updated
	totalAmount = initInv;

	//Display the year-end data with Additional Monthly Deposits
	cout<< "\n\n Balance and Interest with Additional Monthly Deposits\n";
	cout << "==============================================================\n";
	cout << "Year\t\tYear End Balance\t Year End Earned Interests\n";
	cout << "------------------------------------------------------------\n";

	for (int i = 0; i < years; i++) {

		//Set the yearly interests at zero at the beginning of the year
		yearTotInt = 0;

		for (int j = 0; j < 12; j++) {

			//Calculate monthly interests
			intAmt = (totalAmount + monDep) * ((AnuInt / 100) / 12);

			//Calculate  month-end interest
			yearTotInt = yearTotInt + intAmt;

			//Calculate month-end total
			totalAmount = totalAmount + monDep + intAmt;
		}

		//print results to table showcasing only two decimal points
		cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalAmount << "\t\t\t$" << yearTotInt << "\n";
	}

	return 0;

}