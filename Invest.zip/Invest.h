#include<iostream>
using namespace std;
class Invest {
	//Declare the variables for input
	float initInv;
	float monDep;
	float AnuInt;
	float months;
	float years;
	//Declare variable to store year end total amount, interest and year end interest
	float totalAmount;
	float intAmt;
	float yearTotInt;
	
	//setters and getters
	void getInitialInvestment::setInitInv{
		initialInvestment = initInv;
	}
		void getMoneyDeposit::setMonDep{
			moneyDeposit = monDep;

	}
		void getAnnualInterest::setAnuInt{
			annualInvestment = AnuInt;
	}
		void getMonths::setMonths{
			Months = months;
	}
		void getYears::setYears{
			years = years;
	}
		void getTotalAmount::setTotalAmount{
			TotalAmount = totalAmount;
	}
		void getInputAmount::setIntAmt{
		inputAmount = intAmt;
	}
		void getYearTotalInterest::setYearTotInt{
		YearTotalInterest = yearTotInt;
	}
	return 0;
};
	